print(lol().lol.p:lmao())
