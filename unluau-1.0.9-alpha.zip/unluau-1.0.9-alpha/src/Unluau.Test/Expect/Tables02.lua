if buffer then
   print("buffer")
end
local var0 = { table_elt = 6 }
local var1 = { 1, 6, 3, 2, 6, 3, 2, 6, 6 }
