﻿for var3 in pairs(t) do
   print(var3)
end
for var9, var10 in ipairs(t) do
   print(var9, var10)
end
for var17, var18 in next, t do
   print(var17, var18)
end
for var28 in { "a", "b", "c" } do
   print(var28)
end