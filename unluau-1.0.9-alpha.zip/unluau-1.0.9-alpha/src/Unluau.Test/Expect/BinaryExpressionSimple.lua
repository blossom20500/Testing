local var0 = x * (y + z)
local var1 = (x - w) * (y + z)
