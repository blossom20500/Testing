function f(...)
   return g(...)
end

