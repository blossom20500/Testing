local var0 = x or y
local var1 = x and y
