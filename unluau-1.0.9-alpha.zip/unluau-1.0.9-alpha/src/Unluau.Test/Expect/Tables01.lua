local var0 = {}
var0.first = 1
var0.second = 2
var0.third = 3
y = { first = 1, second = 2, third = 3 }
