﻿for var0 = 10, 1, -1 do
   print(var0)
end