print(`message {os.clock()}`)
