print(("message %*"):format(os.clock()))
